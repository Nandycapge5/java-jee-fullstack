package com.mob.dao;

import org.junit.Assert;
import org.junit.Test;

import com.mob.bean.Account;

//import junit.framework.Assert;

public class AccountDaoimplTest {
	AccountDao dao = new AccountDaoImpl();

	@Test
	public void testRecharge_1() {
		String mobileNo = "9010210131";
		Account accountBefore = dao.getAccountDetails(mobileNo);
		System.out.println("account=" + accountBefore.getAccountBalance());
		int result = dao.rechargeAccount(mobileNo, 15);
		int expectedResult = 647;
		Assert.assertEquals(expectedResult, result);

		// restoring old state
		dao.rechargeAccount(mobileNo, -15);

	}
}
