package com.mob.except;

public class AccountIdNotFoundException extends RuntimeException{
	
public  AccountIdNotFoundException(String msg) {
	super(msg);
	}
}
