import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { DisplayEmployeeComponent } from './display-employee/display-employee.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClient,HttpClientModule } from '../../node_modules/@angular/common/http';
import { MyServiceService } from './my-service.service';

import { ModeldrivenComponent } from './modeldriven/modeldriven.component';

@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    DisplayEmployeeComponent, 
    ModeldrivenComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
 
  ],
  providers: [HttpClient,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
