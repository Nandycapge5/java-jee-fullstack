import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { DisplayEmployeeComponent } from './display-employee/display-employee.component';
const routes: Routes=[

{
  path:'',
  component:DisplayEmployeeComponent
},
  {
  path:'Employee-List',
  component:AddEmployeeComponent
  
  },
  {
  path:'Display-List',
 component:DisplayEmployeeComponent
  
  }
];
  
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  
  exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }
