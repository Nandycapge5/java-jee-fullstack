import { Component, OnInit } from '@angular/core';
import { Employee, MyServiceService } from '../my-service.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
createdEmployee:Employee;

service:MyServiceService;
  constructor(service:MyServiceService ,private router:Router) {
this.service=service;
    
   }

  ngOnInit() {
  }

  add(data:any)
  {
    this.createdEmployee=new Employee(data.id,data.name);

  this.service.add(this.createdEmployee);
this.router.navigateByUrl('Display-List');

  }

}
