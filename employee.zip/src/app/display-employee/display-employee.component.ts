import { Component, OnInit } from '@angular/core';

import { MyServiceService, Employee } from '../my-service.service';
@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit {
service:MyServiceService;

  constructor(service:MyServiceService) {
    this.service=service;
   }
employees:Employee[]=[];

  ngOnInit() {
    this.service.fetchEmployee();
    this.employees=this.service.getEmployee();
  }
  delete(id:number)
  {
    this.service.delete(id);
  }

}
