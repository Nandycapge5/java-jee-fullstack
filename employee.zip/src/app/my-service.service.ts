import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
http:HttpClient;
employees:Employee[]=[];
  constructor(http:HttpClient) {
this.http=http;

   }
   fetched:boolean=false;
   fetchEmployee()
   {
     this.http.get('./assets/employees.json')
     .subscribe(
       data=> {
         if(!this.fetched)
         {
           this.convert(data);
           this.fetched=true;
         }
       }
     );
   }
   getEmployee():Employee[]

{
  return this.employees;
} 

convert(data1:any)
{
  for(let o of data1)
  {
    let e=new Employee(o.id,o.name);
    this.employees.push(e);

  }
}

delete(id:number)
{
  let foundIndex:number=-1;
  for(let i=0;i<this.employees.length;i++)
  {
    let e=this.employees[i];
    if(e.id==e.id)
{foundIndex=i;
  break;

}  }

this.employees.splice(foundIndex,1);
}
add(e:Employee)
{
this.employees.push(e);
}
}

export class Employee{
  id:number;
  name:String;
  constructor(id:number,name:string)
  {
    this.id=id;
    this.name=name;
  }
}
