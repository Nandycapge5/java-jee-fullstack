import java.util.Scanner;

public class Vowels {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the vowels");
	String a=sc.next();
	int vowels=0;
	for(int i=0;i<a.length();i++)
	{
		char ch=a.charAt(i);
	
	if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
	{
		vowels++;
	}
}
	System.out.println("Vowels:"+vowels);
}
}
