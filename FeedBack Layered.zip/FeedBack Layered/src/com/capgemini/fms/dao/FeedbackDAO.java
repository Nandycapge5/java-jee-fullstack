package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Map;

public class FeedbackDAO implements IFeedbackDAO {
	Map<String, Integer>MathFeedbackMap= new HashMap<> ();

	Map<String, Integer>EnglishFeedbackMap=new HashMap<> ();

	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		// TODO Auto-generated method stub
		MathFeedbackMap.put(name, rating);
		EnglishFeedbackMap.put(name,rating);
		return MathFeedbackMap;
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
//if
		// TODO Auto-generated method stub
		/*EnglishFeedbackMap.putAll(MathFeedbackMap);
		
		return EnglishFeedbackMap;
		
		
		Map<String, Integer> a=EnglishFeedbackMap.getRating();*/
					{
			
	}
					return EnglishFeedbackMap;
	
	}
}
