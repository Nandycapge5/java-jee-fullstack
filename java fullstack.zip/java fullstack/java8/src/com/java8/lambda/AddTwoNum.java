package com.java8.lambda;

import java.util.Scanner;

@FunctionalInterface
interface Add
{
	public int add(int a,int b);
	
}






public class AddTwoNum {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter the first number");
		int c=s.nextInt();
		System.out.println("Enter the second number");
		int d=s.nextInt();
		Add f=(a,b)->(a+b);
		System.out.println(f.add(c, d));
}
}
