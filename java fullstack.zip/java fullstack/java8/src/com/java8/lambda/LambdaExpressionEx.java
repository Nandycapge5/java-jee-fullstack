package com.java8.lambda;

import java.util.Scanner;

@FunctionalInterface
	interface Function
	{
		public void color();
		
	}




	public class LambdaExpressionEx {
		public static void main(String[] args) {
		
			Function f=()->System.out.println("My favourite sports team is :Cricket");
			f.color();
		}
	}

