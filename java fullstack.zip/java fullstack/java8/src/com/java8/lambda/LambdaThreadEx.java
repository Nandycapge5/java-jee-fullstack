package com.java8.lambda;
/*class ThreadEx implements Runnable
{

	@Override
	public void run() {
	System.out.println("Thread Method");
		
	}
	
}
*/



public class LambdaThreadEx {
public static void main(String[] args) {
	//ThreadEx t=new ThreadEx();
	
	Runnable r=()->{
		for(int i=0;i<10;i++)
		{
			System.out.println("child Thread");
		}};
	
	Thread t1=new Thread(r);
	t1.start();
	for(int i=0;i<5;i++){
		System.out.println("Main Thread");
	}
	System.out.println(Thread.currentThread());

	}
	}

