package com.java8.lambda;

import java.util.Scanner;

interface LengthEx
{
	public int length(String name);
}
public class Lengthlambda {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the string");
String a=sc.next();


LengthEx f=name-> name.length();
System.out.println(f.length(a));

}
}
