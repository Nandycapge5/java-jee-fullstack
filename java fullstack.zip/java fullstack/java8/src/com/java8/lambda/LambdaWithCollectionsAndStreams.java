package com.java8.lambda;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class LambdaWithCollectionsAndStreams {
public static void main(String[] args) {
	ArrayList<Integer> al=new ArrayList<Integer>();
	al.add(10);
	al.add(20);
	al.add(30);
	System.out.println(al);
	
	//to find even numbers using map objects
	List<Integer> l=al.stream().filter(i->i%2==0).collect(Collectors.toList());
	System.out.println("filter to print even values"+l);
	
	//map to double
	List<Integer> k=al.stream().map(i->i*2).collect(Collectors.toList());
	System.out.println("map to double value"+k);
	//count
	long c=al.stream().count();
	System.out.println("it will count no of elements"+c);
	
	//descendig order using comparator
	List<Integer> d=al.stream().sorted((i1,i2) -> (i1<i2)? 1:(i1>i2)?-1:0).collect(Collectors.toList());
	System.out.println("dispalying in descending order"+d);
	
	//minimum value
	Integer minval=al.stream().min((i1,i2) -> -i1.compareTo(i2)).get();
	System.out.println("minimum value is"+minval);
	
	//maximum value
	Integer maxval=al.stream().max((i1,i2) -> i2.compareTo(i1)).get();  //descending order
	System.out.println("maximum value is"+maxval);
	
	//printing using foreach
	
	al.stream().forEach(i ->{
		System.out.println("the elements");
	});
}
}
