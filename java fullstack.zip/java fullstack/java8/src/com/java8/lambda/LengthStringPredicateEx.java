package com.java8.lambda;

import java.util.function.Predicate;

public class LengthStringPredicateEx {
public static void main(String[] args) {
	String[] a={"nandy","Samvitha"};
	Predicate<String> p=b->b.length()%5==0 ;
	for(String c:a){
		if(p.test(c))
		{
			System.out.println(c);
		}
	}
}
}
