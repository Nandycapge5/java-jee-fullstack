package com.java8.lambda;

import java.util.Comparator;
import java.util.TreeMap;

public class LambdaComparatorEx {
public static void main(String[] args) {
	//Comparator<Integer> c=(a,b)->{return (a<b)?a:(a>b)?-1:0;};

	Comparator<Integer> c1=(a,b)->{return -a.compareTo(b);};
	
	Comparator <Integer> c2=(a,b)->{return -b.compareTo(a);};
	TreeMap<Integer, String> t= new TreeMap<Integer,String>(c2);
	t.put(1, "Nandy");
	t.put(12, "Menaka");
	t.put(3, "pooja");
	System.out.println(t);
}
}
