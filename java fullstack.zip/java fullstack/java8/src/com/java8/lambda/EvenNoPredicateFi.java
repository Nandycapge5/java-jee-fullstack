package com.java8.lambda;

import java.util.function.Predicate;

public class EvenNoPredicateFi {
public static void main(String[] args) {
	int [] a={23,24,25,26,28};
	Predicate<Integer> p=i->i % 2== 0;
	for(int b:a)
	{
		if(p.test(b))
		{
			System.out.println(b);
		}
	}
}
}
