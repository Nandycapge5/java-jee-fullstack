package com.java8.functional;

import java.util.Date;
import java.util.function.Supplier;

public class SupplierEx {
	public static void main(String[] args) {
		//Supplier<Date> sup=()->new Date();
	Supplier<String> sup=()->
	{
		
	String otp="";
	for(int i=0;i<6;i++)
	{
		otp=otp+(int)(Math.random()*10);
	}
	return otp;

	};
System.out.println(sup.get());
	
	
	}
	}

