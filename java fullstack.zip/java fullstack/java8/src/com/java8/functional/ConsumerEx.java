package com.java8.functional;

import java.util.function.Consumer;

public class ConsumerEx {
public static void main(String[] args) {
	Consumer<Integer> c=i->System.out.println(i*i);
	c.accept(2);
	c.accept(4);
	
}
}
