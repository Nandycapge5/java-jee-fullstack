package com.java8.functional;

interface A{
	void m1();
	default void m2(){
		System.out.println("Interface defalut method2");
		
	}
	default void m3(){
		System.out.println("Interface defalut method3");
		
	}

}
public class defaultEx implements A{

	@Override
	public void m1() {
		System.out.println("The dafault calss method implementation");		
	}

	public static void main(String[] args) {
		defaultEx d=new defaultEx();
		d.m1();
		d.m2();
		d.m3();
		
	}
}
