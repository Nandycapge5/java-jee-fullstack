package com.lab.lab4;

import java.util.Scanner;

public class SumOfTheCube {
	
	    void calculation(int num)
	    {
	        int a;
	        int digitsum=0;
	        while(num!=0)
	        {
	             a = num % 10;
	                a = a * a * a;
	                digitsum = digitsum + a;
	                num = num / 10;    
	        }
	        System.out.println(digitsum);
	    }
	public static void main(String args[])
	{
		SumOfTheCube cs=new SumOfTheCube();
	System.out.println("enter the number");
	Scanner s=new Scanner(System.in);
	int n=s.nextInt();
	cs.calculation(n);



	    
	}
	}
	 







