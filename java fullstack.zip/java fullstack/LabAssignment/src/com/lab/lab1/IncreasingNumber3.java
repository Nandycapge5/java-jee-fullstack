package com.lab.lab1;

import java.util.Scanner;

public class IncreasingNumber3 {

	    static boolean checkNumber(int number)          //Check if a number is an increasing number
	    {
	    	   	        int currentDigit;
	    	        boolean flag=false;
	    	        currentDigit=number%10;
	    	        number=number/10;
	    	        while(number>0)
	    	        {
	    	            if(currentDigit<(number%10))
	    	            {
	    	                flag=true;
	    	                break;
	    	            }
	    	            currentDigit=number%10;
	    	            number=number/10;
	    	        }
	    	        if(flag)
	    	        {
	    	           System.out.println("Digits are not increasing number.");
	    	        }
	    	        else
	    	        {            
	    	            System.out.println("Digits are  increasing number.");
	    	        }
	    	        
	    	    return flag;
	    	}
	    	        public static void main(String[] args) {
	    	        System.out.println("Enter the number");
	    	        Scanner sc=new Scanner(System.in);
	    	        int n=sc.nextInt();
	    	        IncreasingNumber3 obj=new IncreasingNumber3();
	    	        obj.checkNumber(n);// Calling calculateDifference method
	    	        sc.close();


	    	    }


	    		    	 








	    }
	

	 

	 

	 

	 
