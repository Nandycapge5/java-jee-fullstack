package com.lab.lab1;

import java.util.Scanner;



public class Power4 {
	private static boolean checkNumber(int n){
		if (n % 2 != 0) {
		      return false;
		    }
		else {

		      for (int i = 0; i <= n; i++) {

		        if (Math.pow(2, i) == n) 
		        	return true;
		      }
		    }
		    return false;
		  }
	public static void main(String[] args) {
   Power4 p=new Power4();
	System.out.println("enter the number");    
   Scanner in = new Scanner(System.in);
	    int n = in.nextInt();
	    
	    
	    if (checkNumber(n)) {
	      
	      System.out.println(n+"power of two");
	    } else {
	    	 System.out.println(n+"not power of two");
	    }
	    
	    System.out.println(p.checkNumber(n));
	  }
}


