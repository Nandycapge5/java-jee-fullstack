package com.lab.lab1;

import java.util.Scanner;


public class Natural1 {
	int calculateSum(int n)
	{ int sum=0;
		for(int i=0;i<=n;i++)
		{
			if((i%3==0) ||(i%5==0))
			sum=sum+i;
				
			}
		return sum;
	}
public static void main(String args[]){
	Natural1 h=new Natural1();
	System.out.println("enter the n natural numbers");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	h.calculateSum(45);
	System.out.println(h.calculateSum(n));
}
}
