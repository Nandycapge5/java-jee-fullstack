package com.lab.lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class FileReader2 {
	 public static void main(String args[]) throws Exception {
	        int c = 0;
	        String k = "Nandhini/samvitha/capgemini";
	        char buffer[] = new char[k.length()];
	        k.getChars(0, k.length(), buffer, 0);
	        FileWriter f1 = new FileWriter("C:/Users/nashanmu/Desktop/java fullstack/LabAssignment/bin/com/lab/lab8/FileReader2");
	        f1.write(buffer);
	        f1.close();
	        FileReader fr = new FileReader("C:/Users/nashanmu/Desktop/java fullstack/LabAssignment/bin/com/lab/lab8/FileReader2");
	        BufferedReader br = new BufferedReader(fr);
	        String t;
	        while ((t = br.readLine()) != null) {
	            c++;
	            System.out.println(c + t);
	        }
	        fr.close();
	    }

	 

	}
	 

