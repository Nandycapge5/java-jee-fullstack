package com.lab.lab8;
import java.util.StringTokenizer;
public class JobSeeker7 {
	
    public static boolean registeringUserName(String s)
        
    {
if(s.endsWith("_job")){
    StringTokenizer st=new StringTokenizer(s,"_job");
    int a=st.nextToken().length();
    if(a>8)
    return true;
    else
        return false;


}
else
return false;}
public static void main(String[] args) {
	JobSeeker7 j=new JobSeeker7();
    System.out.println(j.registeringUserName("Nandhini_job"));
}
}
    






