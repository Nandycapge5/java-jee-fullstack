package com.lab.lab8;

import java.time.LocalDate;
import java.time.Period;

public class DateCalculate6 {
	
	    public  void dateCalculation(LocalDate ld) {
	        LocalDate l=LocalDate.now();
	        Period diff=Period.between(ld, l);
	        System.out.println("date differance yyyy/mm/dd :  "+diff.getYears()+"/"+diff.getMonths()+"/"+diff.getDays());
	    }
	    public static void main(String[] args) {
	        LocalDate ld=LocalDate.of(2018,04,12);
	    DateCalculate6 obj =new DateCalculate6();
	    obj.dateCalculation(ld);

	 

	    }
	}

