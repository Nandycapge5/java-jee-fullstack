package com.lab.lab3;

import java.util.Arrays;

public class ReverseNumber3 {
	

	
		    public int[] getSorted(int a[])
	    {
	         for (int i = a.length-1; i >= 0; i--)
	         {  
	                System.out.print(a[i] + " "); 
	         }
	         Arrays.sort(a);
	         return a;
	    }
	    public static void main(String[] args) 
	    {
	        ReverseNumber3 e=new ReverseNumber3();
	        
	            int a[]={2,3,6};
	            
	            a=e.getSorted(a);
	            System.out.println();
	            for(int i:a)
	            {
	            System.out.print(i+" ");
	            
	            }
	    }
	}
	 






