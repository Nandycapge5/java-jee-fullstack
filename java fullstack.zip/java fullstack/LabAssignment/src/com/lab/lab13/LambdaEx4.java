package com.lab.lab13;

public class LambdaEx4 {
	interface Printable{
	    void print();
	}
	
	int id;
	String name;

	 

	public LambdaEx4()
	{
	    
	}public LambdaEx4(int id,String name)
	{
	    this.id=id;
	    this.name=name;
	}
	public  void saySomthing(){
	    System.out.println("Welcome");
	}
	    public int getId(){
	        return id;
	    }
	    public void setId(int id){
	        this.id=id;
	        
	    }
	    public String getName(){
	        return name;
	    }
	    public void setName(String Name){
	        this.name=name;
	    }
	    public static void main(String args[]){
	    	LambdaEx4 methodreference=new LambdaEx4();//creating object
	        //Referring non static method using reference
	        Printable printable =methodreference:: saySomthing;
	        //calling interface method
	        printable.print();
	        
	    }
	}

