package com.lab.lab13;

public class LambdaEx3 {
	interface Interface3 {
	    public boolean test(String x,String y);
	}
	
	    public static void main(String[] args) {
	        // TODO Auto-generated method stub

	        Interface3 i3 = (name,pass)->{if(name=="Nandy"&&pass=="sam") return true;else return false;};
	        boolean b = i3.test("Kavi", "Rp");
	        System.out.println(b);
	    }

	}
	 


	

