package com.lab.lab5;

class ErrorMessage extends Exception {
	public ErrorMessage(String err) {

		super(err);
	}

}

class Validation {

	public void check(String fname, String lname) throws ErrorMessage {
		{
			if ((fname.length() == 0) || (lname.length() == 0)) {
				throw new ErrorMessage("please enter your firstname and lastname");
			} else {
				System.out.println("your name is" + fname + lname);
			}
		}

	}

}

public class NameValidate4 {
	public static void main(String[] args) throws ErrorMessage {

		Validation v = new Validation();
		v.check("nandhini", "");
	}
}
