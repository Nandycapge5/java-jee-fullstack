package com.lab.lab5;

import java.util.Scanner;

public class Fibonacci2 {
	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of:");
	int num11=sc.nextInt();

	int t1 = 0, t2 = 1;
    System.out.print("First " + num11 + " terms: ");
    for (int i = 1; i <= num11; ++i)
    {
        System.out.print(t1 + "  ");
        int sum = t1 + t2;
        t1 = t2;
        t2 = sum;

}
	}}
	

