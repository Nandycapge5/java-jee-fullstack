package com.lab.lab5;



class Validation1 {

	public void check(int age) throws ErrorMessage {
		{
			if (age<15) {
				throw new ErrorMessage("sorry your age should be above 15");
			} else {
				System.out.println("Welcome" );
			}
		}

	}

}

public class AgeValidate5 {
	public static void main(String[] args) throws ErrorMessage {

		Validation1 v = new Validation1();
		v.check(6);
	}
}

