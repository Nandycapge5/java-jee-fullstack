package com.cg.eis.exception;

import java.util.Scanner;

class EmpDetails
{
    public void Details()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the employee Id:");
        int id=sc.nextInt();
        System.out.println("Enter the employee name");
        String name=sc.next();
        
        System.out.println("Enter the Salary");
        int sal=sc.nextInt();
        if(sal<3000)
        {
            throw new EmployeeException("Sry, your Salary is below 3000");
        }
        System.out.println("Employee id is:"+id);
        System.out.println("Employee name is:"+name);
        System.out.println("Employee name is"+sal);
        
    }
}
public class Employee56 {
	  public static void main(String[] args) {
	        EmpDetails emp=new EmpDetails();
	        emp.Details();
	        
	    }

	 

	}
	 

