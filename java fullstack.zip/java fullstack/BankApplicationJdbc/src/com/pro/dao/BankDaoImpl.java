package com.pro.dao;

import com.pro.except.AccountNotFoundException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pro.bean.Bank;
import com.pro.bean.Transcation;

public class BankDaoImpl implements BankDao {

	@Override
	public long createAccount(Bank bank) {
		// TODO Auto-generated method stub
		Connection conn = DBConnect.getConnection();
		int accNo = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement("insert into bank values(?,accSeq.nextval,?,?,?,?)");
			stmt.setString(1, bank.getAccName());
			stmt.setString(2, bank.getAccType());
			stmt.setString(3, bank.getBranch());
			stmt.setLong(4, bank.getAccBalance());
			stmt.setLong(5, bank.getMobileNo());
			int result = stmt.executeUpdate();
			if (result > 0) {
				PreparedStatement p = conn.prepareStatement("select accSeq.currval from dual");
				ResultSet rs = p.executeQuery();
				rs.next();
				accNo = rs.getInt(1);
				System.out.println("Registered Successfully");
			} else {
				System.out.println("Failed");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accNo;
	}

	@Override
	public long showBalance(long accNo) {
		long value = 0;
		Connection conn = DBConnect.getConnection();
		try {
			PreparedStatement stmt1 = conn.prepareStatement("select accBalance from bank where accNo=?");
			stmt1.setLong(1, accNo);
			ResultSet val1 = stmt1.executeQuery();
			val1.next();
			value = val1.getLong(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return value;
	}

	@Override
	public long deposit(long accNo1, int depositAmt) {
		long deposit = 0;
		int result = 0;
		Connection conn = DBConnect.getConnection();
		PreparedStatement stmt2;
		try {
			stmt2 = conn.prepareStatement("select accBalance from bank where accNo=?");
			stmt2.setLong(1, accNo1);
			ResultSet rs = stmt2.executeQuery();
			rs.next();
			long preBal = rs.getLong(1);
			deposit = preBal + depositAmt;

			PreparedStatement p = conn.prepareStatement("update Bank set accBalance=? where accNo=? ");

			p.setLong(1, deposit);
			p.setLong(2, accNo1);
			result = p.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return deposit;
	}

	@Override
	public long withdraw(long accNo1, int withdrawAmt) {
		long wamount = 0;
		int r = 0;
		Connection conn = DBConnect.getConnection();
		PreparedStatement stmt3;
		try {
			stmt3 = conn.prepareStatement("select accBalance from bank where accNo=?");
			stmt3.setLong(1, accNo1);
			ResultSet rs = stmt3.executeQuery();
			rs.next();
			long preBal = rs.getLong(1);
			wamount = preBal - withdrawAmt;

			PreparedStatement p = conn.prepareStatement("update Bank set accBalance=? where accNo=? ");

			p.setLong(1, wamount);
			p.setLong(2, accNo1);
			r = p.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return wamount;
	}

	@Override
	public long FundTransfer(long accNo3, long accNo4, long amount) {
		Connection conn = DBConnect.getConnection();
		PreparedStatement s1, s2, s3, s4;
		long balance = 0;
		long newBal = 0;
		long bal = 0;
		long newBal1 = 0;
		try {
			s1 = conn.prepareStatement("select accBalance from bank where accNo=?");
			s1.setLong(1, accNo3);
			ResultSet rs = s1.executeQuery();
			rs.next();
			balance = rs.getLong(1);
			newBal = balance - amount;
			s2 = conn.prepareStatement("update Bank set accBalance=? where accNo=? ");
			s2.setLong(1, newBal);
			s2.setLong(2, accNo3);
			int r = s2.executeUpdate();
			s3 = conn.prepareStatement("select accBalance from bank where accNo=?");
			s3.setLong(1, accNo4);
			ResultSet rs1 = s1.executeQuery();
			rs1.next();
			bal = rs1.getLong(1);
			newBal1 = bal + amount;
			s4 = conn.prepareStatement("update Bank set accBalance=? where accNo=? ");
			s4.setLong(1, newBal1);
			s4.setLong(2, accNo4);
			int r1 = s4.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newBal;
	}

	@Override
	public List<Transcation> printTranscation() {
		Connection conn = DBConnect.getConnection();
		PreparedStatement s5, s6, s7, s8;
try {
	s5=conn.prepareStatement("select * from bank");
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		return null;
	}

}