package Fancy;

import java.util.Scanner;

public class ui {
public static void main(String[] args)
{ Shop s=new Shop();
	Scanner sc=new Scanner(System.in);	
	System.out.println("Enter the no of Face creams you want to store:");
	int n=sc.nextInt();
	for(int i=1;i<=n;i++)
	{
	System.out.println("Enter the key"+i);
	int k=sc.nextInt();
	System.out.println("Enter the value"+i);
	String v=sc.next();
	v+=sc.nextLine();
	s.addProductDetails(k,v);
}
	System.out.println(s.getProductMap());
	System.out.println("Enter the product tupe to be searched");
	String p=sc.next();
	
	System.out.println(s.searchBasedOnproduct(p));
}
}
