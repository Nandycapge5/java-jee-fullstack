package Fancy;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Shop {
public Shop(){
	productMap=new TreeMap();
}private Map<Integer,String> productMap;


	


public Map<Integer,String> getProductMap() {
	return productMap;
}

public void setProductMap(Map<Integer,String>productMap)
{
	this.productMap=productMap;

}

public void addProductDetails(int serialNumber,String productName)
{
	productMap.put(serialNumber,productName);


}
public List<String> searchBasedOnproduct(String productType)
{ 
	ArrayList a=new ArrayList(productMap.keySet());
	ArrayList a1=new ArrayList();
	Iterator itr=a.iterator();
	while(itr.hasNext())
	{
		String value=productMap.get(itr.next());
		if(value.contains(productType))
		{
			a1.add(value);
		}
	}
	return a1;
	
}


}
