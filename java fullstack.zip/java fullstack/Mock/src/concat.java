import java.util.Scanner;

public class concat {
public static void main(String[] args)
{Scanner sc=new Scanner(System.in);
	String s1=sc.next();
String s2=sc.next();
	int a=s1.length();
	int b=s2.length();
	int adiff=a-b;
	int bdiff=b-a;
	if(a==b)
	{
		System.out.println(s1.concat(s2));
	}
	else if(a>b)
	{
		s1=s1.substring(adiff);
		System.out.println(s1.concat(s2));
	}
	else if(b>a)
	{
		s2=s2.substring(bdiff);
		System.out.println(s1.concat(s2));
	}
}
}
