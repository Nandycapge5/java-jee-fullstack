import java.util.Scanner;

public class username {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s1=sc.next();
	String s2[]=s1.split("@",2);
	System.out.println(s2[0]);
}
}
