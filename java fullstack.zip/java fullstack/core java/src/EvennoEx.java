import java.util.Scanner;

import sun.applet.Main;

public class EvennoEx {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
/*{ int a[]={2,4,6,5,1};
  for(int i=0;i<5;i++){
	  if(a[i]%2==0)
	  {
		  System.out.println("even:"+a);
	  }
	  else
	  {
		  System.out.println("odd:"+a);
	  }
  }*/

char a=sc.ne;

}
	
	/*Scanner sc=new Scanner(System.in);
}
System.out.println("enter the elements");
int a=sc.nextInt();
	if(a%2==0)
	{
		System.out.println("even number");
	}
	else
		System.out.println("odd number");} */
}

