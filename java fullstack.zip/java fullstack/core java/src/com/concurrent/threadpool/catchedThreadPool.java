package com.concurrent.threadpool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


	class Task1 implements Runnable
	{
		public void run()
		{
		System.out.println("Thread Name"+Thread.currentThread().getName());	
		}
	}


	public class catchedThreadPool {
	public static void main(String[] args)
	{
		ExecutorService service=Executors.newCachedThreadPool();
		for(int i=0;i<100;i++)
		{service.execute(new Task1());}
			System.out.println("Thread name"+Thread.currentThread().getName());
		
	}
	}


