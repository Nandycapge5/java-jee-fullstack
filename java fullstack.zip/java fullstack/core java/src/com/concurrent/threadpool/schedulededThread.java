package com.concurrent.threadpool;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class Task2 implements Runnable
{

	@Override
	public void run() {

		Date date=new Date();
		System.out.println(Thread.currentThread().getName()+""+new SimpleDateFormat("HH:mm:ss").format(date));
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
}





public class schedulededThread {

public static void main(String[] args)
{
ScheduledExecutorService service=Executors.newScheduledThreadPool(0);

//service.schedule(new Task2(), 10, TimeUnit.SECONDS);
//service.scheduleAtFixedRate(new Task2(), 15, 10,TimeUnit.SECONDS );
//After previous task complete
service.scheduleWithFixedDelay(new Task2(), 15, 10,TimeUnit.SECONDS);

}
}
