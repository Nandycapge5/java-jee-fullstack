6  package com.concurrent.threadpool;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sun.applet.Main;

class Task implements Runnable
{
	public void run()
	{
	System.out.println("Thread Name"+Thread.currentThread().getName());	
	}
}


public class singleThreaPool {
public static void main(String[] args)
{
	ExecutorService service=Executors.newSingleThreadExecutor();
	for(int i=0;i<100;i++)
	{service.execute(new Task());}
		System.out.println("Thread name"+Thread.currentThread().getName());
	
}
}
