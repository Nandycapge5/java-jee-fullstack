      package com.concurrent;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

public class CopyOnArraySetEx extends Thread {
	static CopyOnWriteArraySet al=new CopyOnWriteArraySet();
    public void run()
    {
        try {
            sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("child thread updating Al");
        al.add("D");
    }
        public static void main(String[] args) throws InterruptedException {
            al.add("A");
            al.add("B");
            al.add("C");
            CopyOnArraySetEx obj =new CopyOnArraySetEx();
            obj.start();
            Iterator itr=al.iterator();
            while(itr.hasNext())
            {
                String values=(String) itr.next();
                System.out.println("Mainthread iterating values "+values);
                Thread.sleep(1000);
                System.out.println(al);
                
            }
            

 

    }

 

}

