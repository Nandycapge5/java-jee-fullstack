package com.capgemini.fms.ui;

import java.util.Map;
import java.util.Scanner;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.IFeedbackService;
import com.capgemini.fms.service.IFeedbackServiceImpl;

public class Client {

	static IFeedbackService service=new IFeedbackServiceImpl();
	static Scanner sc=new Scanner(System.in);
	static Feedback fb=new Feedback();
	public static void main(String[] args) {
	while(true)
	{
		System.out.println("Feedback Application");
		//All user inputs taken here
		System.out.println("1.Add FeedBack Details");
		System.out.println("2.Print Feedback Report");
		System.out.println("3.Exit");
		System.out.println("Enter the option");
		int option=sc.nextInt();
	
switch(option)
{
case 1:
	  System.out.println("Enter the teacher name");
	  String name=sc.next();
	  System.out.println("Enter the subject name");
	  String subject;
	  boolean isOk=false;
	  do{
	  subject=sc.next();
	  isOk=service.subOk(subject);
	  if(!isOk)
	  {
		  System.out.println("Enter the only maths or English");
		  System.out.println("Enter the Subject");
	  }
	  
	  }while(!isOk);
	  
	  System.out.println("Enter the rating");
	  int rating;
	  boolean isOk1=false;
	  do
		  {
		  rating=sc.nextInt();
		  isOk1=service.rateOk(rating);
		  if(!isOk1)
		  {
			  System.out.println("Enter the rating range should be 1 to 5");
			  System.out.println("Enter the rating");
		  }
		  }while(!isOk1);
Map<String,Integer>  feedback=service.addFeedbackDetails(name, rating, subject);
System.out.println("Teacher"+""+name+""+"has got"+""+rating+"ratings:"+feedback);
System.out.println(feedback);
//fb.setRating(rating);

	  
break;


case 2:
	System.out.println("Printing FeedBack");
	Map<String,Integer> feed1=service.getFeedbackReport();
	System.out.println(feed1);
	break;
}
}
}
}