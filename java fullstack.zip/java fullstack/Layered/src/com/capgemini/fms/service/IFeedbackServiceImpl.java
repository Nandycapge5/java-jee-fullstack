package com.capgemini.fms.service;

import java.util.Map;

import javax.security.auth.Subject;

import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.dao.IFeedbackDAO;

public class IFeedbackServiceImpl implements IFeedbackService {
	IFeedbackDAO dao= new FeedbackDAO(); 
		
		
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		// TODO Auto-generated method stub
		return dao.addFeedbackDetails(name, rating, subject);
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return dao.getFeedbackReport();
	}

	@Override
	public boolean subOk(String subject) {
		// TODO Auto-generated method stub
		if(subject.equalsIgnoreCase("maths")||(subject.equalsIgnoreCase("English")))
		return true;
		else
		return false;
	}

	@Override
	public boolean rateOk(int rating) {
		// TODO Auto-generated method stub
		if(rating<=5)
		return true;
		else
			return false;
	}
	
}
