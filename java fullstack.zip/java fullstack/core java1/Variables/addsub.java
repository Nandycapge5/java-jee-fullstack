class VariableEx
{
static int x=20;
static int y=10;
static void addTwo()
{
int a=20;
int b=12;
int c=a+b;
System.out.println("addition of two numbers"+c);
System.out.println("add"+(x+y));
}
static int subTwo(int a,int b)
{
return a-b;
}
static void subTwo1()
{
int a=20;
int b=12;
int c=a-b;
System.out.println("sub of two numbers"+c);
System.out.println("sub"+(x-y));
}

public static void main(String args[])
{//static method calling

VariableEx.addTwo(); //default mathod calling
VariableEx.subTwo1(); 
System.out.println(VariableEx.subTwo(20,10));//param-method
int sub=VariableEx.subTwo(100,90);//param-method0000D/
System.out.println("welcome");
}
}