abstract class T1
{
	void m1()
	{
		System.out.println("Test1 class a1 method");
	}

	abstract void m3();
}
public  class singleabstract extends T1 {
 void m2()
{
	System.out.println("Test class a1 method");
}
public static void main(String args[])
{
	singleabstract w=new singleabstract();
w.m2();
w.m1();
w.m3();
	}

@Override
void m3() {
	// TODO Auto-generated method stub
	
}
}
