
 class MyException1 extends Exception{
private int age;
public MyException1(int age)
{this.age=age;
	}
public String toString()
{
	return "you are not eligible for vote"+age;
}
}
public class MyException
{
	static void validation(int age1) throws MyException1
	{
		if(age1<18)
		throw new MyException1(5);
			
				else
			System.out.println("you are eligible for vote");
	}
	public static void main(String args[]) throws MyException1{
		MyException.validation(17);
		System.out.println("rest of the code");
	}
}

