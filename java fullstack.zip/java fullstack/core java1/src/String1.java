

      class String1 {
	public static void main(String args[]){
		
	String s1="capgemini";
	String s2="Capgemini";
	String s3=new String("capgemini");
	String s4="hello";
	String s5="hallo";
	String s6="welcome to capgemini";
	char a[]={'c','a','p','g','e','m','i','n','i'};
	System.out.println(s1.equals(s3));//equals method//true
    System.out.println(s1==s3);//s3 is stored in heap area,so return false
	System.out.println(s1.equals(s2));//false
	System.out.println(s1.equalsIgnoreCase(s2));//true
	System.out.println(s1==s2);//false
	System.out.println(s4.compareTo(s5));
	System.out.println("as".equals("as"));
	System.out.println(s1.charAt(3));
	System.out.println(s2.indexOf(s1));;
	System.out.println(String.copyValueOf(a,4,4));//'a' is array,
	//4th index of the array of 4 chars to print
	System.out.println(s6.codePointAt(3));
}

}