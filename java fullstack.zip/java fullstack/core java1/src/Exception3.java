class MyException2 extends Exception{
private int age;

private String name;

public MyException2(String name)
{this.name=name;
	}
public String toString()
{
	return "you are not eligible for vote";
}
}
public class Exception3
{
	static void validation(String name) throws MyException2
	{
		if(name=="abc")
		throw new MyException2("abj");
			
				else
			System.out.println("you are eligible for vote");
	}
	public static void main(String args[]) throws MyException2{
		Exception3.validation("abc");
		System.out.println("rest of the code");
	}
}






