
public class Task8 {
	public static void main(String args[])
	{
String text="b.v.raju college";
String text1;
text1=text.replace(text.substring(4,8),text.substring(4,8).toUpperCase()); 
System.out.println(text1);

}
}
