
public class Excep {
			public static void main(String args[]){
		try{
			int c=12/3;
				try
				{
			System.out.println("division");
			int b=30/2;}
		catch(ArithmeticException e){
			System.out.println("dont enter the denominator"+e);
		}
			try{
				int a[]=new int[5];
				a[3]=30/2;
				}
				catch(ArrayIndexOutOfBoundsException e){
					System.out.println("array index out of range");
				}
					catch(Exception e){
				System.out.println("cant find length of string"+e);
			}}
			finally
			{
				System.out.println("executes every time for closing connection");
			}
			System.out.println("remainaing code executed");
		
		}
		}





