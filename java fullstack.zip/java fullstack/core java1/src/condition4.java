
public class condition4 {
public static void main(String[] args) {
	boolean x=false;boolean b;
	if(b=false)
	{
		System.out.println("hello");
		
	}
	else
	{
		System.out.println("hi");
	}
}
}
