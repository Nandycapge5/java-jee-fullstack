class a{
static void add()
{
	System.out.println("default method");
}
static void add(int a,int b)
{
	System.out.println("addition two numbers (int,int)"+(a+b));	
}
static void add(float a,float b)
{
	System.out.println("addition two numbers (float,float)"+(a+b));	
}
static void add(int a,float b)
{
	System.out.println("addition of two number(int,float)"+(a+b));	
}

static void add(float a,int b)
{
	System.out.println("addition of two number(int,float)"+(a+b));	
}

}

public class overload {
	public static void main(String args[]){
		a.add();
		a.add(3,4);
		a.add(12.1f,4.1f);
		a.add(2,2.4f);
		a.add(4.5f,5);
		
		
		
		
			
	}
	

}
