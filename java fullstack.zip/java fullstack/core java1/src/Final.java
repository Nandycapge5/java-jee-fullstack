class F{
	final int a=23;
	public void m1()
	{ 
		
		int b=12;
		System.out.println(a+b);
	}
	
}

class Gi extends F
{
	public void m1()
	{   a=--a;
	int b=11;
		System.out.println(a+b);
	}
		
}
	 
public class Final extends Gi {
	public static void main(String args[])
	{
		Final o=new Final();
		o.m1();
	}
}
