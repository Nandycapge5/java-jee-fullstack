package com.cap;
   class A
{ private int b=9;
	protected  void m1()
	{
		System.out.println("public method");
		System.out.println(b);
	}
}
public class Test extends A {
 protected int eid=12;
public static void main(String args[]){
	A a=new A();
	a.m1();
}
}
