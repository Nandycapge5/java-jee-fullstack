package labassignment;

import java.util.Arrays;

public class lab3ReverseArray {
int[] reverse(int[] a)
{
	int [] b=new int[a.length];
    Arrays.sort(a);
	
	
	
	return null;
	
}
}
