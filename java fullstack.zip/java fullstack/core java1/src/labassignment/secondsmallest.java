package labassignment;

public class secondsmallest
{ int tmp,a[];
private int i;
	
	int getSecondSmallest(int n)
{
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
				
			{
				tmp=a[i];
				a[i]=a[j];
				a[j]=tmp;
				
				
			}
		}if(a[i]==a[n])
		{
			System.out.println("second smallest");
		}
		
	return 0;
		}
	public static void main(String[] args)
	{
		
		
		secondsmallest s=new secondsmallest();
		s.getSecondSmallest(5);
		int b[]={20,12,14,43,34};
		
	}
}