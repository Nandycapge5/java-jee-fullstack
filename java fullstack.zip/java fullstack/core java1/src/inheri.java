import sun.applet.Main;

 class inheri1{
	

	public void m1()
{
	System.out.println("method1");
	
}
public void m2()
{
	System.out.println("method2");
	
}}
 class hier extends inheri1
{
	public void m3()
	{
		System.out.println("method3");
		
	}
	public void m4()
	{
		System.out.println("method4");
		
	}
}
 class hier1 extends inheri1{
	 
	public void m5()
	{
		System.out.println("method5");
		
	}
	public void m6()
	{
		System.out.println("method6");
		
	}
}
	public class inheri extends hier1{

public static void main(String args[])
	{
	inheri i =new inheri();
	i.m1();
	  i.m2();
	
	  hier h2=new hier ();
	  h2.m3();
	  h2.m4();
	  
	  hier1 h=new hier1();
	h.m5();
	h.m6();
		  
		 
		 
		
		  
		  
		  
	}

}
