package Mapex;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class EmployeeUi {
	public static void main(String[] args)
	{Employee e=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the employee details ");
		int n=sc.nextInt();
		for(int i=1;i<=n;i++)
		{
			System.out.println("Enter the employee id");
			int eid=sc.nextInt();
			System.out.println("Enter the employee salary");
			double esal=sc.nextInt();
			e.addMap(eid,esal);
			
		}
		Map<Integer,Double> val=e.getMap();
		Set set=val.keySet();
	    for(Object o: set )
	    {
	        
	        System.out.println(o+" "+val.get(o));
	    }	    	    System.out.println("Enter the minimum sal");
	    double sal13=sc.nextDouble();
	    System.out.println("Enter the Maximum salary");
	    double sal24=sc.nextDouble();
	    	    Map<Integer,Double> val1 =e.sal(sal13 ,sal24); 
	   
	    	    }
					}
	

