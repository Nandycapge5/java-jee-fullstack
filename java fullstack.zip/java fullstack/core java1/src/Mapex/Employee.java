package Mapex;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Employee {
	private int eid;
	private double esal;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public double getEsal() {
		return esal;
	}

	public void setEsal(double esal) {
		this.esal = esal;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", esal=" + esal + "]";
	}

	Map<Integer, Double> map = new HashMap<Integer, Double>();

	public Map<Integer, Double> addMap(int eid, double esal) {
		map.put(eid, esal);
		return map;

	}

	Map<Integer, Double> sal(double sal1, double sal2) {
		System.out.println("The salary details coming under the given Range : ");
		Set set = map.keySet();

		for (Object p : set) {
			if ((map.get(p) > sal1) && (map.get(p) <= sal2)) {
				System.out.println(p+"  "+map.get(p));
			}
		}
		return map;

	}

	Map<Integer, Double> getMap() {
		return map;
	}

}
