import java.util.Scanner;

import sun.applet.Main;

public class Vibgyor {
public static void main(String[] args)
{Scanner sc=new Scanner(System.in);
	String s="VIBGYOR";
	String a=new String();
	System.out.println("Enter the characters");
	a=sc.next();
	for(int j=0;j<a.length();j++)
	{
		char t=a.charAt(j);
	
	switch(t)
	{
	case 'v':
	System.out.println("Violet");break;
	case 'i':
		System.out.println("indigo");break;
	case 'b':
		System.out.println("Blue");break;
	case 'g':
		System.out.println("green");break;
	case 'y':
		System.out.println("yellow");break;
	case 'o':
		System.out.println("Orange");break;
		
	case 'r':
		System.out.println("red");break;
		
		
	}
}}
}
