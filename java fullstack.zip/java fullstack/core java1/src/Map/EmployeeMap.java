package Map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
class Emp1
{
	String ename;
	int esal;
	
	public void Emp1() {
		// TODO Auto-generated method stub
		
	}
	public Emp1( String ename, int esal) {
		super();
	
		this.ename = ename;
		this.esal = esal;
	}
	@Override
	public String toString() {
		return "Emp1 [mobile_no=" + ", ename=" + ename + ", esal=" + esal + "]";
	}
	
	
}
public class EmployeeMap {
	public static void main(String[] args)
	{ 		Emp1 e1=new Emp1("sam",10000);
	Emp1 e2=new Emp1("nandy",20000);
	Emp1 e3=new Emp1("pooja",15000);
	Emp1 e4=new Emp1("menaka",25000);
	Emp1 e5=new Emp1("magha",30000);
		HashMap<String,Emp1> hm=new HashMap<String,Emp1>();
		hm.put("954237133",e1);
		hm.put("962237133",e2);
		hm.put("744237133",e3);
		hm.put("844237133",e4);
		hm.put("679037133",e5);
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the mobile no");
	String mobileno=sc.next();
		System.out.println(hm.get(mobileno));
		Set s=hm.entrySet();
		Iterator itr=s.iterator();
		
		Emp1 e=hm.get(mobileno);
		System.out.println("old salary:"+e.esal);
		System.out.println("updated salary:"+(e.esal+1000));
		/*while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		//HashMap hm1=new HashMap();
		*/
		
		
}
}
