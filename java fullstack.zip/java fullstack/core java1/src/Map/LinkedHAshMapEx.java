package Map;


import java.util.LinkedHashMap;

public class LinkedHAshMapEx {
	public static void main(String[] args)
	{
		LinkedHashMap<Integer,String> hm=new LinkedHashMap<Integer,String>();
		LinkedHashMap hm1=new LinkedHashMap();
		hm.put(1, "nandy");
		hm.put(2, "sam");
		hm.put(3, "pooja");
		hm.put(1, "menaka");
		hm1.put("magha", 4);
		System.out.println(hm);
		System.out.println(hm1);
	}
}



/*linked hash map
   duplication is not allowed
   insertion order is perserved


*/