package Map;

public class IdentityHashmapex {
public static void main(String[] args){
	
}
}
