package Map;

import sun.applet.Main;
class Map1
{
	String name;
	int id;
	public Map1(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	
}
public class MapEx {
public static void main(String[] args)
{
	Map1 m=new Map1("nandy", 1);
	
}
}