import java.util.Scanner;
public class Square {
static int sum=0,i,a,b;
 static  int  calculateDifference(int n){
	for(int i=0;i<=n;i++)
	{
		a=((n*(n+1)*(2*n+1))/6);
		b=(n*(n+1))/2;
		b=b*b;
		sum=(a-b);
	} 
	return sum;
}
public static void main(String args[]){
	Square s=new Square();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter any number");
	int n=sc.nextInt();
	System.out.println(s.calculateDifference(n));
}
}


