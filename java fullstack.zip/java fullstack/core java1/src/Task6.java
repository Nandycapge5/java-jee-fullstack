import java.util.Scanner;

public class Task6 {
	   public static void main(String[] args){
		      Scanner in = new Scanner(System.in);
		      String s = "";
		      System.out.print("Please give a string: ");
		      String x = in.next();
		      int z = x.length();
		      for(int y = 0; y < z; y++){
		         if(Character.isUpperCase(x.charAt(y))){
		            char w = x.charAt(y);
		           s = s + w + " ";
		         }
		      }
		      System.out.println("The uppercase characters are " + s);
		      //Uppercase
		   }
}
