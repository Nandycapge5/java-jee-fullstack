import sun.applet.Main;

class parents{
	static int a=10;
parents()
{   this(2);
	System.out.println("default constructor");
}
parents(int b)
{
	System.out.println("parameterized constructor");
}
void v()
{
	System.out.println("parent class method");
}
}

public class Super extends parents{
	static int a=2; 
	Super(){
		super();
		super.v();
	
		System.out.println(this.a);
		System.out.println(super.a);
		System.out.println("child class constructor");
		
	}
	public void v2()
	{
		System.out.println("child class mentod");
	}
	public static void main(String args[]){
		Super s=new Super();
		System.out.println(s);
		parents p=new parents(4);
		
	}
}
