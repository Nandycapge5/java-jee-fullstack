import sun.applet.Main;

public class switc {
public static void main(String args[])
	{ int a=9,b=9;
	while(a==b)
	{
		System.out.println("same");break;
}
}
}