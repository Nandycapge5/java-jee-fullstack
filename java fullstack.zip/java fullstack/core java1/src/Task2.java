
public class Task2 {
	public static void main(String[] args) 
	{
		String a="java standard edition";
		
		char[] arr = a.toCharArray();
		arr[0] = Character.toUpperCase(arr[0]);
		arr[5] = Character.toUpperCase(arr[5]);
		arr[14] = Character.toUpperCase(arr[14]);
	String str = new String(arr);
	System.out.println(str);
		
	}
}
