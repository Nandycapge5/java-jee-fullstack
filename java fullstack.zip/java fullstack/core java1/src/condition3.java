import sun.applet.Main;

public class condition3 {
	public static void main(String args[])
{int x=10;
if(x==20){
	System.out.println("hello");
}
else
{
	System.out.println("hi");
}
		}
}
