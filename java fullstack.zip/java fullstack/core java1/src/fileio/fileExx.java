package fileio;

import java.io.File;
import java.io.IOException;

class fileExx {
public static void main(String args[]) throws IOException
{
File f=new File("cap.txt");
System.out.println(f.exists());
System.out.println(f.createNewFile());
System.out.println(f.exists());


}}
