package fileio;

import java.io.File;
import java.io.IOException;

class FileEx {
public static void main(String args[]) throws IOException
{
	File f=new File("myfolder/myfile.txt");
    f.getParentFile().mkdir();
    f.createNewFile();
    System.out.println("done");
}
}
