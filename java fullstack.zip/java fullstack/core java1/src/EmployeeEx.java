import java.util.Scanner;

public class EmployeeEx {
}
