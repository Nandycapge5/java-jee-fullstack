package Threads;
class Test5 extends Thread
{
	public void run()
	{for(int i=0;i<5;i++)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}System.out.println("child thread");
	}
			}
	}

public class jionthread {
public static void main(String[] args) throws InterruptedException
{
	Test5 t=new Test5();
	t.start();
	t.join();
	for (int i = 0; i <5; i++) {
		System.out.println("main thread");
	}
}
}
