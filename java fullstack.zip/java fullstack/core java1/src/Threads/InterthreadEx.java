package Threads;

public class InterthreadEx {
public static void main(String[] args)

{
	}
}
