package Threads;


class Test implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<10;i++)
		{
			System.out.println("child process");
		}
		
	}
	
}
public class implementsthreadEx {
	public static void main(String[] args)
	{
		Test t=new Test();
		Thread tr=new Thread(t);
		tr.start();
		for(int i=0;i<10;i++)
	
	{System.out.println("parent process");
			}
	}

}
