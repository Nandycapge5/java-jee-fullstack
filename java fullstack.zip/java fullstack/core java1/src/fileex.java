import java.io.File;

public class fileex {
File f=new File();
}
