import sun.applet.Main;

public class Test7 {
public Test7()
{
	System.out.println("defaulut");
}
public Test7(String name)
{
	System.out.println("param");
	
}
void method()
{
	
	System.out.println("oiii");}
public Test7(int a,int b)
{
	System.out.println("int param");
}
	public static void main(String args[])
{ Test7 t=new Test7();

Test7 t1=new Test7("sandy");
Test7 t2=new Test7(12,67);
t.method();
}
}
