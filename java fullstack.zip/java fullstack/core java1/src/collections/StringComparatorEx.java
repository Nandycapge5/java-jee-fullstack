package collections;

import java.util.Comparator;
import java.util.TreeSet;

public class StringComparatorEx {
	public static void main(String[] args)
	{TreeSet ts=new TreeSet();
	ts.add("sam");
	ts.add("nandy");
	ts.add("poochi");
		
		System.out.println("set:"+ts);
		
	}
	}
	class MyComaparator1 implements Comparator
	{
		public int compare(Object o1,Object o2)
		{
			String s1=(String) o1;
			String s2=(String) o2;
			//return s2.compareTo(s1);//reverse order//poochi,nandy,sam
			return s1.compareTo(s2);//alphabetical order
		//return -s1.compareTo(s2);//reverse order
		}
	}


