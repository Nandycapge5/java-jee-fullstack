package collections;

import java.util.Vector;

public class VectorEx {
public static void main(String[] args)
{
	Vector v=new Vector();
	v.addElement("Sam");
	v.addElement('a');
	v.addElement("abc");
	v.addElement('a');
	v.addElement("abc");
	v.addElement('a');
	v.addElement("abc");
	v.addElement('a');
	v.addElement("abc");
	v.addElement('a');
	v.addElement("nandy");
	v.addElement('s');
	v.elementAt(0);
	
	//System.out.println(v);
	System.out.println(v.firstElement());
System.out.println(v.lastElement());
	System.out.println(v.size());
System.out.println(v.capacity());
System.out.println(v);
	
}
}
