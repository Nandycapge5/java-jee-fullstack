package collections;

import java.util.HashSet;

public class HashSetEx {
	public static void main(String[] args)
	{
		
HashSet hs=new HashSet();
 hs.add(13);
 hs.add(13);
 hs.add("abc");
 hs.add("sam");
 hs.add('s');              //insertion is not preserved
 System.out.println(hs);
	}

}
