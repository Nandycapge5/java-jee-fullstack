package collections;

import java.util.LinkedHashSet;

public class LinkedHashSetEx {
	public static void main(String[] args)
	{
		
LinkedHashSet lhs=new LinkedHashSet();
 lhs.add(13);
 lhs.add(13);
 lhs.add("abc");
 lhs.add("sam");
 lhs.add('s');              
 System.out.println(lhs);
}
}

//insertion is preserved
//duplication is not allowed