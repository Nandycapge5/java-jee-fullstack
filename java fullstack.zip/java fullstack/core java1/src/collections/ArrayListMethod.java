package collections;

import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListMethod {
public static void main(String[]args)

{
	ArrayList al=new ArrayList();
al.add(123);
al.add("abc");
al.add('a');
//al.remove(1);
System.out.println(al);
ArrayList al2=new ArrayList();
al2.add("nandy");
al2.add('c');
System.out.println(al2);
al2.addAll(al);
System.out.println(al2);
//al.removeAll(al2);
System.out.println(al);

//al2.retainAll(al);
System.out.println(al2);
//al.trimToSize();//prints the 4 elements in the array
}
}
