package collections;

import java.awt.List;
import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorEx {
public static void main(String[] args)
{
	ArrayList li=new ArrayList();
	li.add("nandy");
	li.add("sam");
	li.add("poochi");
	li.add("menaka");
	System.out.println(li);
	ListIterator ltr=li.listIterator();
	while(ltr.hasNext())
	{
		System.out.println(ltr.next());
	}
	System.out.println('\n');
	System.out.println("backward direction");
	while(ltr.hasPrevious())
{     
		
		String val=(String) ltr.previous();
		if(val.equals("sam"))
		{
		ltr.set("samvitha");
		ltr.add("sam3");
		System.out.println(ltr.next());
		ltr.previous();
		System.out.println(ltr.previous());
		}
		else{
			System.out.println(val);
		}
}
}}
