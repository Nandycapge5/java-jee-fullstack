package collections;

import java.util.ArrayList;
import java.util.LinkedList;

public class Linkedlist1 {
	public static void main(String[] args)
	{
	LinkedList l=new LinkedList();
	l.add(123);
	l.add("abc");
	l.add('a');
	
	l.add(3,'b');
	System.out.println(l);
	LinkedList l2=new LinkedList();
	l2.add("nandy");
	l2.add('c');
	System.out.println(l2);
	l2.addAll(l);
	//System.out.println(l2);
	//al.removeAll(al2);
	System.out.println(l);
l.getFirst();
	//al2.retainAll(al);
	System.out.println(l2);
	//al.trimToSize();//prints the 4 elements in the array
}
}