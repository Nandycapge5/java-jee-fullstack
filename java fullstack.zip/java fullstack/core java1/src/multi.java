class cap{
	
	public void m8()
{
	System.out.println("method8");
	
}
public void m9()
{
	System.out.println("method9");
	
}}
 class hi2 extends cap
{
	public void m10()
	{
		System.out.println("method10");
		
	}
	public void m11()
	{
		System.out.println("method11");
		
	}
}
 class hi3 extends hi2
 {
 	public void m12()
 	{
 		System.out.println("method12");
 		
 	}
 	public void m13()
 	{
 		System.out.println("method13");
 		
 	}
 }
 class cap1
 {
	 public void m14()
	 {
		 System.out.println("metho14");
	 }
 }
 class hyb extends cap1
 {
	 public void m15()
	 {
		 System.out.println("method15");
	 }
 }
public class multi {
	public static void main(String args[])
	{
		hi3 n =new hi3();
		n.m8();
		n.m9();
		n.m10();
		n.m11();
		n.m12();
		n.m13();
		hyb d=new hyb();
		d.m14();
		d.m15();
	}
}
