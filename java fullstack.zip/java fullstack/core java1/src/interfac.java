
 interface Test1
{
	 void m2();
	 void m3();
}
	public class interfac implements Test1 {
	public void m1()
	{
		System.out.println("Test1 class a1 method");
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		
	}
	public static void main(String args[])
	{
		interfac i=new interfac();
		i.m1();
		i.m2();
		i.m3();
	}

	
	}

