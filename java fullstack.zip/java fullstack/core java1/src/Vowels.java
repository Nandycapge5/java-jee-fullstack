import java.util.Scanner;

import sun.applet.Main;

public class Vowels {
	public static void main(String argsp[])
	{
		scanner sc=new scanner(System.in);
	}
}
