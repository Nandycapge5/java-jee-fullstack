package com.capgemini.takehome.bean;

public class Product {
private int productId;
private String productname;
}
