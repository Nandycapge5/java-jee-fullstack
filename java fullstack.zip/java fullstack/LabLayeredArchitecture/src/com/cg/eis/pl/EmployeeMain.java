package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class EmployeeMain {
	  public static void main(String[] args) {
	        // TODO Auto-generated method stub
	        EmployeeService abc=new EmployeeServiceImpl();
	        Employee e=new Employee();
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter employee details");
	        System.out.println("Enter employee Name");
	        String employeeName=sc.next();
	        System.out.println("Enter employee ID");
	        int employeeId=sc.nextInt();
	        System.out.println("Enter employee salary");
	        int salary=sc.nextInt();
	        
	        abc.getEmployeeDetails(employeeId, employeeName, salary);
	    }    
	        
	}
	 

