package com.junit.test;

public class AddTest {
	

	public int sum(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println("Add:"+a+b);
		return a+b;
		
	}
	
}
