package com.junit.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestEx1 {
AddTest t=new AddTest();
int i=t.sum(1220, 20);
int j=1240;
	@Test
	public void test() {
		
		
		
System.out.println("Sum is:"+i+"+"+j);	
assertEquals(i, j);
		//fail("Not yet implemented");
	}

}
