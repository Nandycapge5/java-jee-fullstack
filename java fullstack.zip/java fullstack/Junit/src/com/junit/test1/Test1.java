package com.junit.test1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class Test1 {
@Before
	public void m2()
{
	System.out.println("executes before  each @Test case");
}
@BeforeClass
public static void m3()
{
	System.out.println("executes only one time  and test");
}
@After
public  void m4()
{
	System.out.println("executes After each @Test case");
}
@AfterClass
public static void m5()
{
	System.out.println("executes only one time  and last");
}
@Test
public void m6()
{
	System.out.println("Test case2");
}
@Ignore
public void m7()
{
	System.out.println("it will ignored by junit compiler");
}
}
