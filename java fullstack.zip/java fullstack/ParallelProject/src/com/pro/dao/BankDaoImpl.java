package com.pro.dao;

public class BankDaoImpl implements BankDao{
	Map<Long, Bank> banks = new HashMap<Long, Bank>();
	Map<Transaction, Long> trans = new HashMap<Transcation, Long>();

	@Override
	public Bank createAccount(Bank bank) {
		banks.put(bank.getAccNo(), bank);

		return banks.get(bank.getAccNo());

	}

	public Bank showBalance(long accNo) {
		Bank bank = banks.get(accNo);
		if (bank == null) {
			throw new AccountNotFoundException("No Account found with this given account number");
		}
		return bank;

	}

	@Override
	public Bank deposit(long accNo1, int depositAmt) {
		Bank amount = banks.get(accNo1);
		long balance1 = amount.getAccBalance();
		long balance2 = balance1 + depositAmt;
		amount.setAccBalance(balance2);
		Transcation t = new Transcation();
		t.setTid(123);
		t.setToAcc(accNo1);
		t.setOldBal(balance2);
		t.setNewbal(depositAmt);
		String accType = "savings";
		t.setTransType(accType);
		trans.put(t, accNo1);
		return amount;

	}

	@Override
	public Bank withdraw(long accNo1, int withdrawAmt) {
		Bank amount = banks.get(accNo1);
		if (amount != null) {
		}
		long balance1 = amount.getAccBalance();
		long balance2 = balance1 - withdrawAmt;
		amount.setAccBalance(balance2);
		Transcation t = new Transcation();
		t.setTid(123);
		t.setFromAcc(balance1);
		t.setToAcc(accNo1);
		t.setOldBal(balance2);
		t.setNewbal(withdrawAmt);
		String accType = "savings";
		t.setTransType(accType);
		trans.put(t, accNo1);

		return amount;

	}

	public long FundTransfer(long accNo3, long accNo4, long amount) {
		Bank amount1 = banks.get(accNo3);

		Bank amount2 = banks.get(accNo4);
		long frombal = amount1.getAccBalance();
		long tobal = amount2.getAccBalance();
		long fromupdatebal = frombal - amount;
		long toupdatebal = tobal + amount;
		amount1.setAccBalance(fromupdatebal);
		amount2.setAccBalance(toupdatebal);

		Transcation t = new Transcation();
		t.setTid(123);
		t.setFromAcc(fromupdatebal);
		t.setToAcc(tobal);
		t.setOldBal(frombal);
		t.setNewbal(toupdatebal);
		String accType = "savings";
		t.setTransType(accType);
		trans.put(t, accNo3);
		trans.put(t, accNo4);

		return fromupdatebal;

	}

	@Override
	public List<Transcation> printTranscation() {
		System.out.println(trans.size());
		List<Transcation> list = new ArrayList<Transcation>(trans.keySet());
		return list;
	}

}

}
